import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Briefcase, GraduationCap, TrendingUp, ExternalLink } from "lucide-react";
import { getCareerRecommendations, getCourseRecommendations } from "@/lib/mockAI";

interface CareerRecommendationsProps {
  resumeData: any;
  skillsData: any;
}

const CareerRecommendations = ({ resumeData, skillsData }: CareerRecommendationsProps) => {
  const careers = getCareerRecommendations(resumeData, skillsData);
  const courses = getCourseRecommendations(resumeData, skillsData);

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fade-in">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">Your Personalized Career Path</h2>
        <p className="text-muted-foreground">Based on your skills and experience</p>
      </div>

      {/* Career Recommendations */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Briefcase className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-bold">Recommended Career Paths</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {careers.map((career, i) => (
            <Card key={i} className="p-6 hover:shadow-elegant transition-all animate-slide-up" style={{animationDelay: `${i * 0.1}s`}}>
              <div className="space-y-4">
                <div>
                  <h4 className="text-xl font-semibold mb-2">{career.title}</h4>
                  <p className="text-sm text-muted-foreground">{career.description}</p>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-4 h-4 text-accent" />
                    <span className="font-medium">{career.match}% Match</span>
                  </div>
                  <Badge variant="secondary">{career.level}</Badge>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-2">Key Skills Required:</p>
                  <div className="flex flex-wrap gap-2">
                    {career.requiredSkills.map((skill: string, j: number) => (
                      <span key={j} className="px-2 py-1 bg-primary/10 text-primary rounded text-xs">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-sm font-semibold mb-1">Avg. Salary:</p>
                  <p className="text-lg font-bold text-accent">{career.salary}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Course Recommendations */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-6 h-6 text-accent" />
          <h3 className="text-2xl font-bold">Recommended Courses & Certifications</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {courses.map((course, i) => (
            <Card key={i} className="p-6 hover:shadow-elegant transition-all animate-slide-up" style={{animationDelay: `${i * 0.1}s`}}>
              <div className="space-y-4">
                <div>
                  <Badge className="mb-3">{course.provider}</Badge>
                  <h4 className="font-semibold mb-2">{course.title}</h4>
                  <p className="text-sm text-muted-foreground">{course.duration}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-semibold">Skills you'll gain:</p>
                  <div className="flex flex-wrap gap-1">
                    {course.skills.map((skill: string, j: number) => (
                      <span key={j} className="px-2 py-1 bg-accent/10 text-accent rounded text-xs">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                <Button variant="outline" className="w-full" size="sm">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Course
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CareerRecommendations;
