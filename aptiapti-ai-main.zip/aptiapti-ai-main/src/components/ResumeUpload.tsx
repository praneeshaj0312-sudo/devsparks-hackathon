import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, FileText, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { analyzeResume } from "@/lib/mockAI";

interface ResumeUploadProps {
  onAnalysisComplete: (data: any) => void;
}

const ResumeUpload = ({ onAnalysisComplete }: ResumeUploadProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setAnalysis(null);
    }
  };

  const handleAnalyze = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload a resume first",
        variant: "destructive",
      });
      return;
    }

    setAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const result = analyzeResume(file.name);
      setAnalysis(result);
      setAnalyzing(false);
      toast({
        title: "Analysis Complete",
        description: "Your resume has been analyzed successfully",
      });
      onAnalysisComplete(result);
    }, 2000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">Resume Analysis</h2>
        <p className="text-muted-foreground">Upload your resume for AI-powered career insights</p>
      </div>

      <Card className="p-8">
        <div className="space-y-6">
          <div className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-primary transition-colors">
            <input
              type="file"
              id="resume-upload"
              className="hidden"
              accept=".pdf,.doc,.docx"
              onChange={handleFileChange}
            />
            <label htmlFor="resume-upload" className="cursor-pointer">
              <Upload className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium mb-2">Drop your resume here or click to browse</p>
              <p className="text-sm text-muted-foreground">Supports PDF, DOC, DOCX (Max 5MB)</p>
            </label>
          </div>

          {file && (
            <div className="flex items-center gap-3 p-4 bg-primary/5 rounded-lg">
              <FileText className="w-8 h-8 text-primary" />
              <div className="flex-1">
                <p className="font-medium">{file.name}</p>
                <p className="text-sm text-muted-foreground">{(file.size / 1024).toFixed(2)} KB</p>
              </div>
            </div>
          )}

          <Button 
            onClick={handleAnalyze} 
            disabled={!file || analyzing}
            className="w-full"
            size="lg"
          >
            {analyzing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing Resume...
              </>
            ) : (
              "Analyze Resume"
            )}
          </Button>
        </div>
      </Card>

      {analysis && (
        <Card className="p-6 animate-slide-up">
          <h3 className="text-xl font-bold mb-4">Analysis Results</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-sm text-muted-foreground mb-2">Detected Skills</h4>
              <div className="flex flex-wrap gap-2">
                {analysis.skills.map((skill: string, i: number) => (
                  <span key={i} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm text-muted-foreground mb-2">Experience Level</h4>
              <p className="text-lg">{analysis.experience}</p>
            </div>
            <div>
              <h4 className="font-semibold text-sm text-muted-foreground mb-2">Career Focus</h4>
              <p className="text-lg">{analysis.focus}</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default ResumeUpload;
