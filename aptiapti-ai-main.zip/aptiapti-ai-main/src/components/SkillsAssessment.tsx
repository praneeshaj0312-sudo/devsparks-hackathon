import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

interface SkillsAssessmentProps {
  onComplete: (data: any) => void;
}

const skillCategories = {
  "Programming Languages": ["JavaScript", "Python", "Java", "C++", "TypeScript", "Go"],
  "Web Development": ["React", "Node.js", "HTML/CSS", "REST APIs", "GraphQL", "Next.js"],
  "Data Science": ["Machine Learning", "Data Analysis", "SQL", "TensorFlow", "Pandas", "Statistics"],
  "Design": ["UI/UX Design", "Figma", "Adobe Suite", "Prototyping", "User Research", "Wireframing"],
  "Soft Skills": ["Communication", "Leadership", "Problem Solving", "Time Management", "Teamwork", "Critical Thinking"],
};

const SkillsAssessment = ({ onComplete }: SkillsAssessmentProps) => {
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const { toast } = useToast();

  const toggleSkill = (skill: string) => {
    setSelectedSkills(prev => 
      prev.includes(skill) 
        ? prev.filter(s => s !== skill)
        : [...prev, skill]
    );
  };

  const handleSubmit = () => {
    if (selectedSkills.length === 0) {
      toast({
        title: "No skills selected",
        description: "Please select at least one skill",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Assessment Complete",
      description: `${selectedSkills.length} skills recorded`,
    });

    onComplete({
      skills: selectedSkills,
      categories: Object.keys(skillCategories).filter(cat => 
        skillCategories[cat as keyof typeof skillCategories].some(s => selectedSkills.includes(s))
      ),
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold">Skills Assessment</h2>
        <p className="text-muted-foreground">Select the skills you have experience with</p>
      </div>

      <Card className="p-8">
        <div className="space-y-8">
          {Object.entries(skillCategories).map(([category, skills]) => (
            <div key={category} className="space-y-4">
              <h3 className="text-lg font-semibold text-primary">{category}</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {skills.map(skill => (
                  <label
                    key={skill}
                    className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-accent/5 cursor-pointer transition-colors"
                  >
                    <Checkbox
                      checked={selectedSkills.includes(skill)}
                      onCheckedChange={() => toggleSkill(skill)}
                    />
                    <span className="text-sm">{skill}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-border">
          <p className="text-sm text-muted-foreground mb-4">
            Selected: {selectedSkills.length} skills
          </p>
          <Button onClick={handleSubmit} size="lg" className="w-full">
            Complete Assessment
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default SkillsAssessment;
