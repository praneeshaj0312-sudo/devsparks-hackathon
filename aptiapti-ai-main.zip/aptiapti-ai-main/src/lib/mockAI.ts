// Mock AI functions to simulate backend AI processing

export const analyzeResume = (filename: string) => {
  const mockSkills = [
    "JavaScript", "React", "Node.js", "Python", "SQL", 
    "Git", "REST APIs", "Problem Solving", "Communication"
  ];
  
  return {
    skills: mockSkills.slice(0, Math.floor(Math.random() * 3) + 5),
    experience: ["Entry Level", "Mid-Level", "Senior"][Math.floor(Math.random() * 3)],
    focus: ["Software Development", "Data Science", "Web Development", "Full Stack"][Math.floor(Math.random() * 4)],
  };
};

export const getCareerRecommendations = (resumeData: any, skillsData: any) => {
  const allSkills = [
    ...(resumeData?.skills || []),
    ...(skillsData?.skills || []),
  ];

  const careers = [
    {
      title: "Full Stack Developer",
      description: "Build end-to-end web applications using modern frameworks and databases",
      match: 92,
      level: "Mid-Level",
      requiredSkills: ["React", "Node.js", "SQL", "REST APIs"],
      salary: "$80,000 - $120,000",
    },
    {
      title: "Frontend Developer",
      description: "Create beautiful, responsive user interfaces for web applications",
      match: 88,
      level: "Entry-Mid",
      requiredSkills: ["React", "JavaScript", "HTML/CSS", "TypeScript"],
      salary: "$70,000 - $110,000",
    },
    {
      title: "Data Analyst",
      description: "Transform data into actionable insights using analytics tools",
      match: 85,
      level: "Entry-Mid",
      requiredSkills: ["Python", "SQL", "Data Analysis", "Statistics"],
      salary: "$65,000 - $95,000",
    },
    {
      title: "Software Engineer",
      description: "Design and develop scalable software solutions",
      match: 90,
      level: "All Levels",
      requiredSkills: ["JavaScript", "Python", "Problem Solving", "Git"],
      salary: "$75,000 - $130,000",
    },
  ];

  return careers.sort((a, b) => b.match - a.match);
};

export const getCourseRecommendations = (resumeData: any, skillsData: any) => {
  const courses = [
    {
      title: "Advanced React Development",
      provider: "Coursera",
      duration: "6 weeks",
      skills: ["React", "TypeScript", "State Management"],
    },
    {
      title: "Full Stack Web Development Bootcamp",
      provider: "Udemy",
      duration: "12 weeks",
      skills: ["Node.js", "MongoDB", "REST APIs"],
    },
    {
      title: "Data Science with Python",
      provider: "edX",
      duration: "8 weeks",
      skills: ["Python", "Pandas", "Machine Learning"],
    },
    {
      title: "AWS Cloud Practitioner",
      provider: "AWS",
      duration: "4 weeks",
      skills: ["Cloud Computing", "AWS", "DevOps"],
    },
    {
      title: "UI/UX Design Fundamentals",
      provider: "Interaction Design Foundation",
      duration: "5 weeks",
      skills: ["Figma", "User Research", "Prototyping"],
    },
    {
      title: "SQL for Data Analysis",
      provider: "LinkedIn Learning",
      duration: "3 weeks",
      skills: ["SQL", "Database Design", "Data Analysis"],
    },
  ];

  return courses.slice(0, 6);
};

export const getChatResponse = (userMessage: string) => {
  const lowerMessage = userMessage.toLowerCase();

  if (lowerMessage.includes("career") || lowerMessage.includes("job")) {
    return "Based on current market trends, tech careers are growing rapidly. Software development, data science, and cloud engineering are particularly in demand. What specific field interests you?";
  }

  if (lowerMessage.includes("skill") || lowerMessage.includes("learn")) {
    return "Great question! The most valuable skills right now include:\n\n1. Programming (JavaScript, Python)\n2. Cloud platforms (AWS, Azure)\n3. Data analysis and AI/ML\n4. Soft skills like communication and problem-solving\n\nWhich area would you like to focus on?";
  }

  if (lowerMessage.includes("salary") || lowerMessage.includes("pay")) {
    return "Salaries vary by role and location. For example:\n- Entry-level developers: $60-80k\n- Mid-level engineers: $80-120k\n- Senior roles: $120-180k+\n\nWould you like specific information about a particular role?";
  }

  if (lowerMessage.includes("resume") || lowerMessage.includes("cv")) {
    return "For a strong resume:\n\n✓ Highlight measurable achievements\n✓ Use action verbs\n✓ Tailor to each job\n✓ Include relevant skills\n✓ Keep it concise (1-2 pages)\n\nWould you like help optimizing your resume?";
  }

  if (lowerMessage.includes("interview")) {
    return "Interview tips:\n\n1. Research the company thoroughly\n2. Prepare STAR method examples\n3. Practice common technical questions\n4. Prepare thoughtful questions\n5. Follow up with a thank you\n\nWhat type of interview are you preparing for?";
  }

  return "I can help you with:\n\n• Career path recommendations\n• Skill development advice\n• Salary insights\n• Resume tips\n• Interview preparation\n• Job market trends\n\nWhat would you like to explore?";
};
