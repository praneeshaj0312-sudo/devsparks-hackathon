import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Upload, Target, TrendingUp, MessageSquare } from "lucide-react";
import ResumeUpload from "@/components/ResumeUpload";
import SkillsAssessment from "@/components/SkillsAssessment";
import CareerRecommendations from "@/components/CareerRecommendations";
import AIChat from "@/components/AIChat";

const Index = () => {
  const [activeSection, setActiveSection] = useState<"home" | "resume" | "skills" | "recommendations" | "chat">("home");
  const [resumeData, setResumeData] = useState<any>(null);
  const [skillsData, setSkillsData] = useState<any>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Navigation */}
      <nav className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              CareerAI
            </h1>
            <div className="flex gap-2">
              <Button 
                variant={activeSection === "home" ? "default" : "ghost"}
                onClick={() => setActiveSection("home")}
              >
                Home
              </Button>
              <Button 
                variant={activeSection === "resume" ? "default" : "ghost"}
                onClick={() => setActiveSection("resume")}
              >
                Resume Analysis
              </Button>
              <Button 
                variant={activeSection === "skills" ? "default" : "ghost"}
                onClick={() => setActiveSection("skills")}
              >
                Skills Assessment
              </Button>
              <Button 
                variant={activeSection === "recommendations" ? "default" : "ghost"}
                onClick={() => setActiveSection("recommendations")}
                disabled={!resumeData && !skillsData}
              >
                Recommendations
              </Button>
              <Button 
                variant={activeSection === "chat" ? "default" : "ghost"}
                onClick={() => setActiveSection("chat")}
              >
                AI Chat
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {activeSection === "home" && (
          <div className="max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
            <div className="space-y-4">
              <h2 className="text-5xl font-bold bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
                Your AI-Powered Career Guide
              </h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Get personalized career recommendations based on your skills, interests, and market trends
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
              <div className="p-6 rounded-lg bg-card border border-border/50 hover:shadow-elegant transition-all cursor-pointer animate-slide-up" onClick={() => setActiveSection("resume")}>
                <Upload className="w-12 h-12 text-primary mb-4 mx-auto" />
                <h3 className="font-semibold text-lg mb-2">Resume Analysis</h3>
                <p className="text-sm text-muted-foreground">Upload your resume for AI-powered insights</p>
              </div>

              <div className="p-6 rounded-lg bg-card border border-border/50 hover:shadow-elegant transition-all cursor-pointer animate-slide-up" style={{animationDelay: "0.1s"}} onClick={() => setActiveSection("skills")}>
                <Target className="w-12 h-12 text-accent mb-4 mx-auto" />
                <h3 className="font-semibold text-lg mb-2">Skills Assessment</h3>
                <p className="text-sm text-muted-foreground">Evaluate your skills and find gaps</p>
              </div>

              <div className="p-6 rounded-lg bg-card border border-border/50 hover:shadow-elegant transition-all cursor-pointer animate-slide-up" style={{animationDelay: "0.2s"}} onClick={() => setActiveSection("recommendations")}>
                <TrendingUp className="w-12 h-12 text-primary mb-4 mx-auto" />
                <h3 className="font-semibold text-lg mb-2">Career Paths</h3>
                <p className="text-sm text-muted-foreground">Discover personalized career recommendations</p>
              </div>

              <div className="p-6 rounded-lg bg-card border border-border/50 hover:shadow-elegant transition-all cursor-pointer animate-slide-up" style={{animationDelay: "0.3s"}} onClick={() => setActiveSection("chat")}>
                <MessageSquare className="w-12 h-12 text-accent mb-4 mx-auto" />
                <h3 className="font-semibold text-lg mb-2">AI Chat</h3>
                <p className="text-sm text-muted-foreground">Get instant career guidance</p>
              </div>
            </div>

            <Button size="lg" className="mt-8" onClick={() => setActiveSection("resume")}>
              Get Started
            </Button>
          </div>
        )}

        {activeSection === "resume" && (
          <ResumeUpload onAnalysisComplete={(data) => {
            setResumeData(data);
            setActiveSection("recommendations");
          }} />
        )}

        {activeSection === "skills" && (
          <SkillsAssessment onComplete={(data) => {
            setSkillsData(data);
            setActiveSection("recommendations");
          }} />
        )}

        {activeSection === "recommendations" && (
          <CareerRecommendations resumeData={resumeData} skillsData={skillsData} />
        )}

        {activeSection === "chat" && <AIChat />}
      </main>
    </div>
  );
};

export default Index;
